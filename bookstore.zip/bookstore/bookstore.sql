-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2021 at 06:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `checkout_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `1` int(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`1`, `username`, `password`) VALUES
(1, 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(100) NOT NULL,
  `book_name` varchar(300) NOT NULL,
  `img` varchar(300) NOT NULL,
  `author` varchar(200) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `price` varchar(200) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_name`, `img`, `author`, `isbn`, `price`, `category`) VALUES
(5, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '500', 'cmp'),
(6, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '300', 'cmp'),
(7, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'cmp'),
(8, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'bs'),
(9, 'India At Risk', 'book_img/5.jpg', 'Jaswant Singh', '90053410', '199', 'na'),
(10, 'The Red Sari', 'book_img/6.jpg', 'Javier Moro', '90053456', '135', 'na'),
(11, 'The power of  Mind', 'book_img/7.jpg', 'Joseph Murphy', '90053459', '231', 'bs'),
(12, 'Think And Grow Rich', 'book_img/8.jpg', 'Napoleon Hill', '900534523', '150', 'bs'),
(13, 'Siddartha', 'book_img/9.jpg', 'Herman Hesse', '900534987', '299', 'na'),
(14, 'Black Holes', 'book_img/10.jpg', 'Stephen Hawking', '900534987', '199', 'na'),
(15, 'The Theory Of Everything', 'book_img/11.jpg', 'Stephen Hawking', '900534981', '205', 'st'),
(16, 'Relativity', 'book_img/12.jpg', 'Albert Einstein', '900534988', '190', 'st'),
(17, 'The Wellness Sense', 'book_img/13.jpg', 'Om Swami', '900534983', '200', 'iw'),
(18, 'The Gene', 'book_img/14.jpg', 'Siddarta Mukherjee', '900534789', '215', 'na'),
(19, 'Sapiens', 'book_img/15.jpg', 'Yuval Noah Harari', '900534780', '216', 'iw'),
(20, 'One Word Kill', 'book_img/16.jpg', 'Mark Lawrence', '900534782', '180', 'aa'),
(21, 'Jurrasic Park', 'book_img/17.jpg', 'Michael Crichton\r\n', '900534567', '240', 'aa'),
(22, 'The Hobbit', 'book_img/18.jpg', 'J.R.R. Tolkien\r\n\r\n', '900534561', '340', 'aa'),
(23, 'The Hunger Games', 'book_img/19.jpg', 'Suzanne Collins\r\n', '90053456', '310', 'na'),
(24, 'The Fellowship of the Ring ', 'book_img/20.jpg', 'J.R.R. Tolkien', '900534645', '300', 'na'),
(25, 'The Da Vinci Code', 'book_img/21.jpg', 'Dan Brown', '900534678', '230', 'aa'),
(26, 'The Girl with the Dragon Tattoo ', 'book_img/21.jpg', 'Stieg Larsson,\r\nReg Keeland ', '900534678', '230', 'na'),
(27, 'On Becoming a Leader', 'book_img/22.jpg', 'Warren G. Bennis', '900534672', '230', 'na'),
(28, 'Financial Intelligence', 'book_img/23.jpg', 'Karen Berman and Joe Knight ', '900534908', '250', 'na'),
(29, ' Growing a Business', 'book_img/24.jpg', 'Paul Hawken ', '900534999', '260', 'bm'),
(30, 'What Management Is', 'book_img/25.jpg', 'Joan Magretta', '900534991', '140', 'bm'),
(31, 'Rich Dad Poor Dad:', 'book_img/26.jpg', 'Robert T. Kiyosaki', '900534998', '210', 'bm'),
(32, 'India in the Age of Ideas', 'book_img/27.jpg', ' 	\r\nSanjeev Sanyal', '900534430', '230', 'bm'),
(33, 'Thinking, Fast and Slow ', 'book_img/28.jpg', 'Daniel Kahneman', '900534436', '270', 'bm'),
(34, 'The Lean Startup', 'book_img/29.jpg', 'Eric Ries', '900534430', '230', 'bm'),
(35, 'Captain Marvel', 'book_img/30.jpg', 'Kelly Sue DeConnick', '900534431', '299', 'com'),
(36, 'The Meltdown', 'book_img/31.jpg', 'Jeff Kinney ', '9005344231', '279', 'com'),
(37, 'Saga', 'book_img/32.jpg', 'Brian K. Vaughan ', '9005344213', '240', 'com'),
(38, 'Ultimate Spider-Man', 'book_img/33.jpg', 'Brian Michael Bendis  ', '9005344215', '230', 'com'),
(39, 'Captain America', 'book_img/34.jpg', 'Ed Brubaker ', '90053442345', '220', 'com'),
(40, 'All Star Superman', 'book_img/35.jpg', 'Grant Morrison', '900534424', '290', 'com'),
(41, 'Wonderstruck', 'book_img/36.jpg', 'Brian Selznick', '900534422', '249', 'com'),
(42, 'Ashoka the Great', 'book_img/37.jpg', 'Maple Press ', '900534412', '160', 'nov'),
(43, 'Biography: S.C. Bose', 'book_img/38.jpg', 'RPH Editorial Board ', '9005344456', '180', 'nov'),
(45, 'The Perfect Murder', 'book_img/40.jpg', 'Ruskin Bond', '90053446', '210', 'nov'),
(46, 'Sherlock Holmes vol 2', 'book_img/41.jpg', 'Sir Arthur Conan Doyale ', '900534456', '220', 'nov'),
(47, 'Manto:Selected Short Stories', 'book_img/42.jpg', 'Saadat Hasan Manto ', '900534451', '100', 'iw'),
(48, 'Wings of Fire', 'book_img/43.jpg', 'Arun Tiwari ', '900534452', '170', 'iw'),
(50, 'The Forever War', 'images/160338419847042625_379136152824987_3805429337373540352_n.jpg', 'Lalit Kumar', '', '300', 'sfi'),
(51, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '500', 'cmp'),
(52, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '300', 'cmp'),
(53, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'cmp'),
(54, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'bs'),
(55, 'India At Risk', 'book_img/5.jpg', 'Jaswant Singh', '90053410', '199', 'bs'),
(56, 'The Red Sari', 'book_img/6.jpg', 'Javier Moro', '90053456', '135', 'bs'),
(57, 'The power of  Mind', 'book_img/7.jpg', 'Joseph Murphy', '90053459', '231', 'bs'),
(58, 'Think And Grow Rich', 'book_img/8.jpg', 'Napoleon Hill', '900534523', '150', 'bs'),
(59, 'Siddartha', 'book_img/9.jpg', 'Herman Hesse', '900534987', '299', 'bs'),
(60, 'Black Holes', 'book_img/10.jpg', 'Stephen Hawking', '900534987', '199', 'st'),
(61, 'The Theory Of Everything', 'book_img/11.jpg', 'Stephen Hawking', '900534981', '205', 'st'),
(62, 'Relativity', 'book_img/12.jpg', 'Albert Einstein', '900534988', '190', 'st'),
(63, 'The Wellness Sense', 'book_img/13.jpg', 'Om Swami', '900534983', '200', 'iw'),
(64, 'The Gene', 'book_img/14.jpg', 'Siddarta Mukherjee', '900534789', '215', 'iw'),
(65, 'Sapiens', 'book_img/15.jpg', 'Yuval Noah Harari', '900534780', '216', 'iw'),
(66, 'One Word Kill', 'book_img/16.jpg', 'Mark Lawrence', '900534782', '180', 'aa'),
(67, 'Jurrasic Park', 'book_img/17.jpg', 'Michael Crichton\r\n', '900534567', '240', 'aa'),
(68, 'The Hobbit', 'book_img/18.jpg', 'J.R.R. Tolkien\r\n\r\n', '900534561', '340', 'aa'),
(69, 'The Hunger Games', 'book_img/19.jpg', 'Suzanne Collins\r\n', '90053456', '310', 'aa'),
(70, 'The Fellowship of the Ring ', 'book_img/20.jpg', 'J.R.R. Tolkien', '900534645', '300', 'aa'),
(71, 'The Da Vinci Code', 'book_img/21.jpg', 'Dan Brown', '900534678', '230', 'aa'),
(72, 'The Girl with the Dragon Tattoo ', 'book_img/21.jpg', 'Stieg Larsson,\r\nReg Keeland ', '900534678', '230', 'aa'),
(73, 'On Becoming a Leader', 'book_img/22.jpg', 'Warren G. Bennis', '900534672', '230', 'bm'),
(74, 'Financial Intelligence', 'book_img/23.jpg', 'Karen Berman and Joe Knight ', '900534908', '250', 'bm'),
(75, ' Growing a Business', 'book_img/24.jpg', 'Paul Hawken ', '900534999', '260', 'bm'),
(76, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '500', 'cmp'),
(77, 'Let Us C++', 'book_img/index.jpg', 'Yashwant Kanetkar', '90073467', '300', 'cmp'),
(78, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'cmp'),
(79, 'Hello World', 'book_img/3.jpg', 'Hannah Fry', '90053400', '300', 'bs'),
(80, 'India At Risk', 'book_img/5.jpg', 'Jaswant Singh', '90053410', '199', 'bs'),
(81, 'The Red Sari', 'book_img/6.jpg', 'Javier Moro', '90053456', '135', 'bs'),
(82, 'The power of  Mind', 'book_img/7.jpg', 'Joseph Murphy', '90053459', '231', 'bs'),
(83, 'Think And Grow Rich', 'book_img/8.jpg', 'Napoleon Hill', '900534523', '150', 'bs'),
(84, 'Siddartha', 'book_img/9.jpg', 'Herman Hesse', '900534987', '299', 'bs'),
(85, 'Black Holes', 'book_img/10.jpg', 'Stephen Hawking', '900534987', '199', 'st'),
(86, 'The Theory Of Everything', 'book_img/11.jpg', 'Stephen Hawking', '900534981', '205', 'st'),
(87, 'Relativity', 'book_img/12.jpg', 'Albert Einstein', '900534988', '190', 'st'),
(88, 'The Wellness Sense', 'book_img/13.jpg', 'Om Swami', '900534983', '200', 'iw'),
(89, 'The Gene', 'book_img/14.jpg', 'Siddarta Mukherjee', '900534789', '215', 'iw'),
(90, 'Sapiens', 'book_img/15.jpg', 'Yuval Noah Harari', '900534780', '216', 'iw'),
(91, 'One Word Kill', 'book_img/16.jpg', 'Mark Lawrence', '900534782', '180', 'aa'),
(92, 'Jurrasic Park', 'book_img/17.jpg', 'Michael Crichton\r\n', '900534567', '240', 'aa'),
(93, 'The Hobbit', 'book_img/18.jpg', 'J.R.R. Tolkien\r\n\r\n', '900534561', '340', 'aa'),
(94, 'The Hunger Games', 'book_img/19.jpg', 'Suzanne Collins\r\n', '90053456', '310', 'aa'),
(95, 'The Fellowship of the Ring ', 'book_img/20.jpg', 'J.R.R. Tolkien', '900534645', '300', 'aa'),
(96, 'The Da Vinci Code', 'book_img/21.jpg', 'Dan Brown', '900534678', '230', 'aa'),
(97, 'The Girl with the Dragon Tattoo ', 'book_img/21.jpg', 'Stieg Larsson,\r\nReg Keeland ', '900534678', '230', 'aa'),
(98, 'On Becoming a Leader', 'book_img/22.jpg', 'Warren G. Bennis', '900534672', '230', 'bm'),
(99, 'Financial Intelligence', 'book_img/23.jpg', 'Karen Berman and Joe Knight ', '900534908', '250', 'bm'),
(100, ' Growing a Business', 'book_img/24.jpg', 'Paul Hawken ', '900534999', '260', 'bm');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(255) NOT NULL,
  `book_id` varchar(100) NOT NULL,
  `book_name` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `price` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `user_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(100) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `city` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `sno` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `book_id` varchar(200) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `img` varchar(200) NOT NULL,
  `price` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `date_of_purchase` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `paid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_address`
--

CREATE TABLE `order_address` (
  `id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `order_id` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile_images`
--

CREATE TABLE `profile_images` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`1`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `order_address`
--
ALTER TABLE `order_address`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `profile_images`
--
ALTER TABLE `profile_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `1` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_address`
--
ALTER TABLE `order_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_images`
--
ALTER TABLE `profile_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
