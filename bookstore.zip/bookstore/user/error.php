<?php


	

?>

<style type="text/css">
	h1{

		color: red;
	}

	#img{

		margin: auto;
		position: absolute;
		left: 30%;

	}

</style>


<img src="images/de.jpg" height="600" width="600" id="img">